package com.shailly;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class Controller {

    private final int PLUS_PRIORITY = 1;   // + and - have the same priority

    private final int MULTIPLY_PRIORITY = 2; // * and / have the same priority

    private final int PARENTHESIS_PRIORITY = 0; // assume the priority of parenthesis(left) to be 0

    // * and / have more priority than + and -

    private String expression = ""; // start with the empty expression

    private int operatorsCount = 0; // used to count the number of operators in the expression
    // help to save the stack size

    private int getPriority(String s){
        // returns the priority of the given operator
        if(s.equals("+") || s.equals("-")){
            return PLUS_PRIORITY;
        }else if(s.equals("*") || s.equals("/")){
            return MULTIPLY_PRIORITY;
        }else{
            return PARENTHESIS_PRIORITY;
        }
    }

    @FXML
    public Button one, two, three, four, five, six, seven, eight, nine, zero,
            plus, minus, multiply, divide, result, quit, clear, backspace, dot,
            left, right;
    @FXML
    public TextArea screen;



    // we split the each and every part of the expression using space as delimeter
    // Suppose we have an expression 9+3.45*(3*5-4) then in the expression it will be stored as
    // 9 + 3.45 * ( 3 * 5 - 4 )
    // reason for doing this is that we can easily convert the string to numbers
    // and this will help in evaluating the infix expression using stack

    public void onButtonClicked(ActionEvent e) {
        // handle the mouse clicked action events
        // manages the screen output
        if (e.getSource().equals(one)) {
            screen.appendText("1");
            expression += "1";
        } else if (e.getSource().equals(two)) {
            screen.appendText("2");
            expression += "2";
        } else if (e.getSource().equals(three)) {
            screen.appendText("3");
            expression += "3";
        } else if (e.getSource().equals(four)) {
            screen.appendText("4");
            expression += "4";
        } else if (e.getSource().equals(five)) {
            screen.appendText("5");
            expression += "5";
        } else if (e.getSource().equals(six)) {
            screen.appendText("6");
            expression += "6";
        } else if (e.getSource().equals(seven)) {
            screen.appendText("7");
            expression += "7";
        } else if (e.getSource().equals(eight)) {
            screen.appendText("8");
            expression += "8";
        } else if (e.getSource().equals(nine)) {
            screen.appendText("9");
            expression += "9";
        } else if (e.getSource().equals(zero)) {
            screen.appendText("0");
            expression += "0";
        } else if (e.getSource().equals(plus)) {
            screen.appendText("+");
            expression += " + ";
            operatorsCount++;
        } else if (e.getSource().equals(minus)) {
            screen.appendText("-");
            expression += " - ";
            operatorsCount++;
        } else if (e.getSource().equals(multiply)) {
            screen.appendText("*");
            expression += " * ";
            operatorsCount++;
        } else if (e.getSource().equals(divide)) {
            screen.appendText("/");
            expression += " / ";
            operatorsCount++;
        } else if (e.getSource().equals(left)) {
            screen.appendText("(");
            expression += "( ";
            operatorsCount++;
        } else if (e.getSource().equals(right)) {
            screen.appendText(")");
            expression += " )";
            operatorsCount++;
        } else if (e.getSource().equals(clear)) {
            screen.clear();
            expression = "";
        } else if (e.getSource().equals(dot)) {
            screen.appendText(".");
            expression += ".";
        } else if (e.getSource().equals(result)) {
            calculateResult();
        } else if (e.getSource().equals(backspace)) {
            String text = screen.getText();
            if(text.isEmpty()){
                expression = "";
            }else{
                char lastCharacter = text.charAt(text.length()-1);
                if(lastCharacter == '+' || lastCharacter == '-' || lastCharacter == '*' || lastCharacter == '/'){
                    expression = expression.substring(0,expression.length()-3);
                }else if(lastCharacter == '(' || lastCharacter == ')'){
                    expression = expression.substring(0,expression.length()-2);
                }else{
                    expression = expression.substring(0,expression.length()-1);
                }
                text = text.substring(0,text.length()-1);
                screen.setText(text);
            }
        } else {
            System.exit(0);
        }
    }

    @FXML
    public void handleMouseEntered(MouseEvent e){
        // to give impressive effects
        // zoom in when mouse hover over the button
        Button button = (Button)e.getSource();
        button.setScaleX(1.1);
        button.setScaleY(1.1);
    }

    @FXML
    public void handleMouseExited(MouseEvent e){
        // to give impressive effects
        // zoom out when mouse exit the button
        Button button = (Button)e.getSource();
        button.setScaleX(1.0);
        button.setScaleY(1.0);
    }

    @FXML
    public void handleKeyPressed(KeyEvent e){
        // handle the keyboard events

        // allow the user to type the expression
        // user-friendly application

        KeyCode code = e.getCode();
        if(code.equals(KeyCode.DIGIT1) || code.equals(KeyCode.NUMPAD1)){
            screen.appendText("1");
            expression += "1";
        }else if(code.equals(KeyCode.DIGIT2)|| code.equals(KeyCode.NUMPAD2)){
            screen.appendText("2");
            expression += "2";
        }else if(code.equals(KeyCode.DIGIT3)|| code.equals(KeyCode.NUMPAD3)){
            screen.appendText("3");
            expression += "3";
        }else if(code.equals(KeyCode.DIGIT4)|| code.equals(KeyCode.NUMPAD4)){
            screen.appendText("4");
            expression += "4";
        }else if(code.equals(KeyCode.DIGIT5)|| code.equals(KeyCode.NUMPAD5)){
            screen.appendText("5");
            expression += "5";
        }else if(code.equals(KeyCode.DIGIT6)|| code.equals(KeyCode.NUMPAD6)){
            screen.appendText("6");
            expression += "6";
        }else if(code.equals(KeyCode.DIGIT7)|| code.equals(KeyCode.NUMPAD7)){
            screen.appendText("7");
            expression += "7";
        }else if(code.equals(KeyCode.DIGIT8)|| code.equals(KeyCode.NUMPAD8)){
            screen.appendText("8");
            expression += "8";
        }else if(code.equals(KeyCode.DIGIT9)|| code.equals(KeyCode.NUMPAD9)){
            screen.appendText("9");
            expression += "9";
        }else if(code.equals(KeyCode.DIGIT0)|| code.equals(KeyCode.NUMPAD0)){
            screen.appendText("0");
            expression += "0";
        }else if(code.equals(KeyCode.ADD)){
            screen.appendText("+");
            expression += " + ";
            operatorsCount++;
        }else if(code.equals(KeyCode.SUBTRACT)){
            screen.appendText("-");
            expression += " - ";
            operatorsCount++;
        }else if(code.equals(KeyCode.MULTIPLY)){
            screen.appendText("*");
            expression += " * ";
            operatorsCount++;
        }else if(code.equals(KeyCode.DIVIDE)){
            screen.appendText("/");
            expression += " / ";
            operatorsCount++;
        }else if(code.equals(KeyCode.BACK_SPACE)){
            String text = screen.getText();
            if(text.isEmpty()){
                expression = "";
            }else{
                char lastCharacter = text.charAt(text.length()-1);
                if(lastCharacter == '+' || lastCharacter == '-' || lastCharacter == '*' || lastCharacter == '/'){
                    expression = expression.substring(0,expression.length()-3);
                }else if(lastCharacter == '(' || lastCharacter == ')'){
                    expression = expression.substring(0,expression.length()-2);
                }else{
                    expression = expression.substring(0,expression.length()-1);
                }
                text = text.substring(0,text.length()-1);
                screen.setText(text);
            }
        }else if(code.equals(KeyCode.PERIOD)){
            screen.appendText(".");
        }else if(code.equals(KeyCode.EQUALS) || code.equals(KeyCode.ENTER)){
            calculateResult();
        }else if(code.equals(KeyCode.ESCAPE)){
            System.exit(0);
        }
    }

    public void calculateResult(){
        // using stack implementation for evaluating the expression
        // $ is used as a delimiter
        String[] parts = expression.split(" ");
        String[] operators = new String[operatorsCount];
        double[] numbers = new double[parts.length];
        int a=-1,b=-1; // index counter for operators and numbers

        try {
            for (String temp : parts) {
                if(temp.equals("+") || temp.equals("-") || temp.equals("*") || temp.equals("/") ){
                    if(a !=-1){
                        while(getPriority(temp) <= getPriority(operators[a])){
                            double num1 = numbers[b];
                            double num2 = numbers[b-1];
                            b -= 2;
                            String op = operators[a];
                            if(op.equals("+")){
                                num2 += num1;
                            }else if(op.equals("-")){
                                num2 -= num1;
                            }else if(op.equals("*")){
                                num2 *= num1;
                            }else if(op.equals("/")){
                                num2 /= num1;
                            }
                            numbers[++b] = num2;
                            a -=1;
                            if( a == -1 ){
                                break;
                            }
                        }
                        operators[++a] = temp;
                    }else{
                        operators[++a] = temp;
                    }
                }else if( temp.equals("(")){
                    operators[++a] = "(";
                }else if(temp.equals(")")){
                    while (!operators[a].equals("(")){
                        double num1 = numbers[b];
                        double num2 = numbers[b-1];
                        b -= 2;
                        String op = operators[a];
                        a -=1;
                        if(op.equals("+")){
                            num2 += num1;
                        }else if(op.equals("-")){
                            num2 -= num1;
                        }else if(op.equals("*")){
                            num2 *= num1;
                        }else if(op.equals("/")){
                            num2 /= num1;
                        }
                        numbers[++b] = num2;
                    }
                    a -=1; // discard the (
                }
                else{
                    double num = Double.parseDouble(temp);
                    numbers[++b] = num;
                }
            }
            while( a != -1){
                double num1 = numbers[b];
                double num2 = numbers[b-1];
                b -= 2;
                String op = operators[a];
                a -=1;
                if(op.equals("+")){
                    num2 += num1;
                }else if(op.equals("-")){
                    num2 -= num1;
                }else if(op.equals("*")){
                    num2 *= num1;
                }else if(op.equals("/")){
                    num2 /= num1;
                }
                numbers[++b] = num2;
            }
        }catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Invalid Expression");
            alert.setContentText("Syntax Error");
            alert.showAndWait();
        }
        expression="" + numbers[0];
        operatorsCount = 0;
        screen.setText(expression);
    }
}
